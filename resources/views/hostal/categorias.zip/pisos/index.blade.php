@extends('layouts.main', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')])
@section('content')
<h1>hola pisos</h1>
@endsection
@notifyCss
@push('js')


@notifyJs
@endpush