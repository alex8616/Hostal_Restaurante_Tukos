@extends('layouts.app', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')])

@section('content')
<br><br><hr>    
<section class="wrapper">
  <div class="container-fostrap">
      <div class="content">
          <div class="container">
              <div class="row">
                @foreach($festivales as $festival)
                  <div class="col-xs-12 col-sm-4">
                      <div class="card card-block">
                      <form action="{{route('admin.festival.reportefestival')}}" target="_blank">
                        <h5 class="card-title mt-3 mb-3">
                        <center><strong>{{ $festival->nombre_festival }}</strong>
                        <br><br>
                        <img src="{{ asset('img/festival/festival_1.jpeg') }}" alt="Mi imagen" class="imagen-estilo">
                        </center></h5><hr>
                        <table style="padding: 2500px;">
                          <tr>
                            <td class="text-center"style="background:#E9E9E9; padding:10px; width: 1000px">
                              <input type="text" id="festival_id" name="festival_id" value="{{ $festival->id }}" hidden>
                              <button type="submit" href="{{ route('admin.festival.reportefestival') }}" target="_blank">TOTAL {{ $festival->registrofestivales->sum('total') }} Bs.</button>
                            </td>
                          </tr>
                        </table>
                        <a href="{{ route('admin.festival.registrar', $festival) }}"
                            class="btn btn-success" style="width: 100%">INGRESAR
                        </a>
                      </form>
                    </div>
                  </div>
                @endforeach
              </div>
              <div>
              </div>
          </div>
      </div>
  </div>
</section>
@endsection
<style>
  .imagen-estilo {
    width: 300px;
    height: 250px;
    box-shadow: 0px 0px 10px 5px rgba(0, 0, 0, 0.5);
  }
</style>
@notifyCss
@push('js')

@notifyJs
@endpush