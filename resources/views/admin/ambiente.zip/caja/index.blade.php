@extends('layouts.app', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')])

@section('content')
<br><br><br><hr>		
<div class="floating-container">
    <button type="button" data-toggle="modal" data-target="#modelId">
        <div class="floating-button">+</div>
    </button>
</div>
    <!--Font-awsome-->
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
    <div class="container">
          <header>
        <div style="text-align:center;margin-top:2px;font-weight:bold;text-decoration:none;">
        </div>            
          </header>
    <div class="xs-menu-cont">
    <a id="menutoggle"><i class="fa fa-align-justify"></i> </a>
      <nav class="xs-menu displaynone">
        <ul>
          <li>
            <a href="{{route('admin.caja.index')}}">CAJA</a>
          </li>
          <li>
            <a href="#">About</a>
          </li>
          <li>
            <a href="#">Services</a>
          </li>
          <li>
            <a href="#">Team</a>
          </li>
          <li>
            <a href="#">Portfolio</a>
          </li>
          <li>
            <a href="#">Blog</a>
          </li>
          <li>
            <a href="#">Contact</a>
          </li>

        </ul>
      </nav>
    </div>
    <nav class="menu">
      <ul>
        <li class="active">
          <a href="{{route('admin.caja.index')}}">CAJA</a>
        </li>
        <li>
          <a href="{{route('admin.caja.codigo')}}">C0DIGOS</a>  
        </li>
        <li>
          <a href="{{route('admin.caja.articulos')}}">ATRIBUTO</a>
        </li>
        <li>
          <a href="#" data-toggle="modal" data-target="#modelIdBuscarCaja">BUSQUEDA PERSONALIZADA</a>
        </li>
        <li>
          <a href="{{route('admin.caja.reportesfull')}}" target="_blank">REPORTE GENERAL</a>
        </li>
        <li>
          <a href="#">EXPORT EXCEL</a>
        </li>
      </ul>
    </nav>
  </div>

<section class="wrapper">
  <div class="container-fostrap">
      <div class="content">
          <div class="container">
              <div class="row">
              @foreach ($cajas as $caja)
                  <div class="col-xs-12 col-sm-4">
                      <div class="card card-block">
                      <form action="{{ route('caja.destroycaja', $caja) }}" method="POST" class="eliminar-form">
                          @method('DELETE')
                          @csrf
                      </form>
                        <h5 class="card-title mt-3 mb-3">
                          <center>CAJA DEL MES <strong>{{ \Carbon\Carbon::parse($caja->fecha_registro)->locale('es')->isoFormat(' MMMM \d\e\l Y') }}</strong>
                        </center></h5><hr>
                        <table style="padding: 2500px;">
                          <tr>
                            <td class="text-center" style="padding-top:10px;"><span class="material-icons" style="font-size:50px">apartment</span></td>
                            <td class="text-center" style="padding-top:10px;"><span class="material-icons" style="font-size:50px">store</span></td>
                            <td class="text-center" style="padding-top:10px;"><span class="material-icons" style="font-size:50px">payment</span></td>
                            <td class="text-center" style="padding-top:10px;"><span class="material-icons" style="font-size:50px">payment</span></td>
                          </tr>
                          <tr>
                            <td class="text-center" style="padding-bottom:10px;">{{$caja->caja_hostal_ingreso-$caja->caja_hostal_egreso}}</td>
                            <td class="text-center" style="padding-bottom:10px;">{{$caja->caja_restaurante_ingreso-$caja->caja_restaurante_egreso}}</td>
                            <td class="text-center" style="padding-bottom:10px;">{{$caja->caja_tarjetas_ingreso}}</td>
                            <td class="text-center" style="padding-bottom:10px;">{{$caja->caja_depositos_ingreso}}</td>
                          </tr>
                          <tr>
                            <td class="text-center" colspan="4" style="background:#E9E9E9; padding:10px;">TOTAL {{$caja->total}}</td>
                          </tr>
                        </table>
                        <a href="{{ route('admin.caja.registrar', $caja) }}"
                            class="btn btn-primary">INGRESAR
                        </a>
                    </div>
                  </div>
                  @endforeach
              </div>
              <div>
              </div>
          </div>
      </div>
  </div>
</section>
    @include('admin.caja.BuscarCaja')
    @include('admin.caja.CrearCaja')
@endsection
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.3.0/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" integrity="sha512-rRQtF4V2wtAvXsou4iUAs2kXHi3Lj9NE7xJR77DE7GHsxgY9RTWy93dzMXgDIG8ToiRTD45VsDNdTiUagOFeZA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="{{asset('css/bottonfooder.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{asset('css/modal.css')}}" rel="stylesheet" type="text/css"/> 
<style>
      .demo-card-square1.mdl-card {
      width: 320px;
      height: 320px;
      margin:auto;
    }
    .demo-card-square1 > .mdl-card__title {
      color: #fff;
      background:
        url('https://cdn3.iconfinder.com/data/icons/google-material-design-icons/48/ic_directions_car_48px-128.png') bottom right 15% no-repeat #46B6AC;
    }
    .demo-card-square2.mdl-card {
      width: 320px;
      height: 320px;
    }
    .demo-card-square2 > .mdl-card__title {
      color: #fff;
      background:
        url('') bottom right 15% no-repeat #46B6AC;
    }
    
    ol, ul {
      list-style: none;
    }
    blockquote, q {
      quotes: none;
    }
    blockquote:before, blockquote:after, q:before, q:after {
      content: '';
      content: none;
    }
    table {
      border-collapse: collapse;
      border-spacing: 0;
    }
    header h2 {
      margin: 25px 10px;
      font-size: 28px;
      text-align: center;
      color:  #ea5849;
    }
    .container {
      margin: 10px auto;
      display: table;
      max-width: 100%;
      width: 100%;
    }

    nav.menu {
      background: #ea5849;
      position: relative;
      min-height: 45px;
      height: 100%;
    }

    .menu > ul > li {
      list-style: none;
      display: inline-block;
      color: #fff;
      line-height: 45px;
      
    }
    .menu > ul li a, .xs-menu li a {
      text-decoration: none;
      color: #fff;
      display:block;
      padding: 0px 24px;
    }
    .menu > ul li a:hover {
      background:#444;
      color: #fff;
      transition-duration: 0.3s;
      -moz-transition-duration: 0.3s;
      -webkit-transition-duration: 0.3s;
    }
   
    .displaynone{
      display: none;
    }
    .xs-menu-cont{
    display:none;
    }
    .xs-menu-cont > a:hover{
    cursor: pointer;
    }
      
    .xs-menu li {
    color: #fff;
    padding: 14px 30px;
    border-bottom: 1px solid #ccc;
    background: #FF0000;

    }
    .xs-menu  a{
    text-decoration:none;
    }

    
    #menutoggle i {
        color: #fff;
        font-size: 33px;
        margin: 0;
        padding: 0;
    }


    /*--column--*/
    .mm-6column:after, .mm-6column:before, .mm-3column:after, .mm-3column:before{
    content:"";
    display:table;
    clear:both;


    }
    .mm-6column, .mm-3column {
    float: left;
    position: relative;
    }
    .mm-6column {
        width: 100%;
    }
    .mm-3column {
            width: 25%;
    }
    .responsive-img {
        display: block;
        max-width: 100%;

    }
    .left-images{
    margin-right:25px;
    }
    .left-images, .left-categories-list {
      float: left;
    }
    .categories-list li {
        display: block;
        line-height: normal;
        margin: 0;
        padding: 5px 0;
    }
    .categories-list li :hover{
        background:inherit !important;
    }

    .categories-list span {
        font-size: 18px;
        padding-bottom: 5px;
        text-transform: uppercase;
    }
    .mm-view-more{
      background: none repeat scroll 0 0 #FF0000;
        color: #fff;
        display: inline !important;
        line-height: normal;
        padding: 5px 8px !important;
      margin-top:10px;
    }
    .display-on{
    display:block;
    transition-duration: 0.9s;
    }
    .drop-down > a:after{
    content:"\f103";
    color:red;
    font-family: FontAwesome;
    font-style: normal;
    margin-left: 5px;
    }

    img{
      height:150px;
      width:100%;
    }

    div [class^="col-"]{
      padding-left:5px;
      padding-right:5px;
    }
    .card{
      transition:0.5s;
      cursor:pointer;
    }
    .card-title{  
      font-size:15px;
      transition:1s;
      cursor:pointer;
    }
    .card-title i{  
      font-size:15px;
      transition:1s;
      cursor:pointer;
      color:#ffa710
    }
    .card-title i:hover{
      transform: scale(1.25) rotate(100deg); 
      color:#18d4ca;
      
    }
    .card:hover{
      transform: scale(1.05);
      box-shadow: 10px 10px 15px rgba(0,0,0,0.3);
    }
    .card-text{
      height:80px;  
    }

    .card::before, .card::after {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      transform: scale3d(0, 0, 1);
      transition: transform .3s ease-out 0s;
      background: rgba(255, 255, 255, 0.1);
      content: '';
      pointer-events: none;
    }
    .card::before {
      transform-origin: left top;
    }
    .card::after {
      transform-origin: right bottom;
    }
    .card:hover::before, .card:hover::after, .card:focus::before, .card:focus::after {
      transform: scale3d(1, 1, 1);
    }
</style>
@notifyCss

@push('js')
{{-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script> --}}
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.8/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.8/js/responsive.bootstrap4.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.16/dist/sweetalert2.all.min.js"></script>

    <script>
        $('.eliminar-form').submit(function(e) {
            e.preventDefault();
            Swal.fire({
                title: 'Quieres eliminar?',
                text: "El registro se eliminara definitivamente!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, eliminar!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    this.submit();
                }
            });
        });
    </script>
    @if (session('delete') == 'ok')
        <script>
            Swal.fire(
                'Eliminar!',
                'Se Eliminó el registro.',
                'success'
            )
        </script>
    @endif
    <script>
        $(document).ready(function() {
            $('#categoria').DataTable({
                responsive: true,
                autoWidth: false,
                "bSort" : false,
                "language": {
                    "lengthMenu": "Mostrar registro por página",
                    "zeroRecords": "No se encontro registro",
                    "info": "Mostrando la página _PAGE_ de _PAGES_",
                    "search": "Buscar",
                    "paginate": {
                        "previous": "Anterior",
                        "next": "Siguiente"
                    },
                    "infoEmpty": "No hay registros",
                    "infoFiltered": "(Filtrado de _MAX_ registros totales)"
                },
                "lengthMenu": [
                    [4, 10, 50, -1],
                    [5, 10, 50, "All"]
                ]

            });
        });
    </script>
    @notifyJs
@endpush