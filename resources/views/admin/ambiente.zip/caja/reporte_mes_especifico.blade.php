<style>
    html {
      font-family: sans-serif;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      border: 2px solid rgb(200,200,200);
      font-size: 0.9rem;
    }

    td, th {
      border: 1px solid rgb(190,190,190);
      padding: 5px 10px;
    }

    th {
      background-color: rgb(235,235,235);
    }

    tr:nth-child(even) td {
      background-color: rgb(250,250,250);
    }

    tr:nth-child(odd) td {
      background-color: rgb(245,245,245);
    }

    caption {
      padding: 10px;
    }
</style>

<table class="table-wrapper">
    <tr>
        <td>FECHA DE CAJAS</td>
        <td>CODIGOS</td>
        <td>INGRESOS</td>
        <td>EGRESOS</td>
        <td>SUB TOTAL</td>
    </tr>
    <tr>
        <td rowspan="10">Reporte De Mes {{$caja->fecha_registro}}</td>
        <td>hostal</td>
        <td>{{$caja->caja_hostal_ingreso}}</td>
        <td>{{$caja->caja_hostal_egreso}}</td>
        @php
            $Rh = $caja->caja_hostal_ingreso - $caja->caja_hostal_egreso
        @endphp
        <td>{{$Rh}}</td>
    </tr>
    <tr>
        <td>Caja Grande</td>
        <td>{{$CajaGrandeHostal}}</td>
        <td>{{$CajaGrandeHostal}}</td>
        <td></td>
    </tr>
    <tr>
        <td style="background: #86B8F5;">TOTAL HOSTAL</td>
        @php
            $hI = $caja->caja_hostal_ingreso + $CajaGrandeHostal;
            $hE = $caja->caja_hostal_egreso - $CajaGrandeHostal
        @endphp
        <td style="background: #86B8F5;">{{$hI}}</td>
        <td style="background: #86B8F5;">{{$hE}}</td>
        <td style="background: #86B8F5;">{{$hI - $hE}}</td>
    </tr>
    <tr>
        <td>Restaurante</td>
        <td>{{$caja->caja_restaurante_ingreso}}</td>
        <td>{{$caja->caja_restaurante_egreso}}</td>
        @php
            $Rr = $caja->caja_restaurante_ingreso - $caja->caja_restaurante_egreso
        @endphp
        <td>{{$Rr}}</td>
    </tr>
    <tr>
        <td>Caja Grande</td>
        <td>{{$CajaGrandeRestaurante}}</td>
        <td>{{$CajaGrandeRestaurante}}</td>
        <td></td>
    </tr>
    <tr>
        <td style="background: #86B8F5;">TOTAL RESTAURANTE</td>
        @php
            $rI = $caja->caja_restaurante_ingreso + $CajaGrandeRestaurante;
            $rE = $caja->caja_restaurante_egreso - $CajaGrandeRestaurante
        @endphp
        <td style="background: #86B8F5;">{{$rI}}</td>
        <td style="background: #86B8F5;">{{$rE}}</td>
        <td style="background: #86B8F5;">{{$rI - $rE}}</td>
    </tr>
    <tr>
        <td>Tarjetas</td>
        <td>{{$caja->caja_tarjetas_ingreso}}</td>
        <td></td>
        <td>{{$caja->caja_tarjetas_ingreso}}</td>
    </tr>
    <tr>
        <td>Depositos</td>
        <td>{{$caja->caja_depositos_ingreso}}</td>
        <td></td>
        <td>{{$caja->caja_depositos_ingreso}}</td>
    </tr>
    <tr>
        <td style="background: #42D958;">TOTAL PARCIAL</td>
        @php
            $Tg1 = $hI+$caja->caja_tarjetas_ingreso+$rI+$caja->caja_depositos_ingreso;
            $Tg2 = $hE+$rE
        @endphp
        <td style="background: #42D958;">{{$Tg1}}</td>
        <td style="background: #42D958;">{{$Tg2}}</td>
        <td style="background: #42D958;">{{$Rh+$Rr+$caja->caja_tarjetas_ingreso+$caja->caja_depositos_ingreso}}</td>
    </tr>
</table>
<table>
    <tr>
        <td>DOLARES </td>
        <td>{{$caja->DolarHostal}} $.</td>
    </tr>
    <tr>
        <td>TOTAL GENERAL</td>
        <td>{{$Tg1-$Tg2}} Bs.</td>
    </tr>
</table>

<div style="page-break-after: always;"></div>

<table>
    @foreach ($diasDelMes as $dia)
        <tr>
            <td colspan="2">
                <h3>Registro CAJA del día {{ $dia->format('Y-m-d') }}</h3>
            </td>
        </tr>
        ty
        @foreach ($registrosPorDia[$dia->format('Y-m-d')] as $registro)
                <tr>
                    <td style="width: 250px;">
                        <p>{{ $registro->Nombre_Articulo }}</p>
                    </td>
                    <td style="background: white;">
                        <p>Descripcion: {{ $registro->Articulo_description }}</p>
                        @if($registro->Ingreso > 0)
                            <p>Ingreso: {{ $registro->Ingreso }}</p>
                        @else 
                            <p>Egreso: {{ $registro->Egreso }}</p>
                        @endif
                    </td>
                </tr>        
        @endforeach
    @endforeach
</table>

