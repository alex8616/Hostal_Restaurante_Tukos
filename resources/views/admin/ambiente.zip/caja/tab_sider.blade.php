<!--Font-awsome-->
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
    <div class="container">
          <header>
            <div style="text-align:center;margin-top:2px;font-weight:bold;text-decoration:none; width:100%">
    </div>            
          </header>
    <div class="xs-menu-cont">
    <a id="menutoggle"><i class="fa fa-align-justify"></i> </a>
      <nav class="xs-menu displaynone">
        <ul>
          <li>
            <a href="{{route('admin.caja.index')}}">CAJA</a>
          </li>
          <li>
            <a href="#">About</a>
          </li>
          <li>
            <a href="#">Services</a>
          </li>
          <li>
            <a href="#">Team</a>
          </li>
          <li>
            <a href="#">Portfolio</a>
          </li>
          <li>
            <a href="#">Blog</a>
          </li>
          <li>
            <a href="#">Contact</a>
          </li>

        </ul>
      </nav>
    </div>
    <nav class="menu">
      <ul>
        <li class="active">
          <a href="{{route('admin.caja.index')}}">CAJA</a>
        </li>
        <li>
          <a href="{{route('admin.caja.codigo')}}">C0DIGOS</a>  
        </li>
        <li>
          <a href="{{route('admin.caja.articulos')}}">ATRIBUTO</a>
        </li>
      </ul>
    </nav>
  </div>