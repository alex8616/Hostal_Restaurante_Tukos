<?php

namespace App\Http\Controllers;

use App\Models\ArticuloCaja;
use Illuminate\Http\Request;

class ArticuloCajaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ArticuloCaja  $articuloCaja
     * @return \Illuminate\Http\Response
     */
    public function show(ArticuloCaja $articuloCaja)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ArticuloCaja  $articuloCaja
     * @return \Illuminate\Http\Response
     */
    public function edit(ArticuloCaja $articuloCaja)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ArticuloCaja  $articuloCaja
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ArticuloCaja $articuloCaja)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ArticuloCaja  $articuloCaja
     * @return \Illuminate\Http\Response
     */
    public function destroy(ArticuloCaja $articuloCaja)
    {
        //
    }
}
