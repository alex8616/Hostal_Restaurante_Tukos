<?php

namespace App\Http\Controllers;

use App\Models\hospedaje_habitacion_invitados;
use Illuminate\Http\Request;

class HospedajeHabitacionInvitadosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\hospedaje_habitacion_invitados  $hospedaje_habitacion_invitados
     * @return \Illuminate\Http\Response
     */
    public function show(hospedaje_habitacion_invitados $hospedaje_habitacion_invitados)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\hospedaje_habitacion_invitados  $hospedaje_habitacion_invitados
     * @return \Illuminate\Http\Response
     */
    public function edit(hospedaje_habitacion_invitados $hospedaje_habitacion_invitados)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\hospedaje_habitacion_invitados  $hospedaje_habitacion_invitados
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, hospedaje_habitacion_invitados $hospedaje_habitacion_invitados)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\hospedaje_habitacion_invitados  $hospedaje_habitacion_invitados
     * @return \Illuminate\Http\Response
     */
    public function destroy(hospedaje_habitacion_invitados $hospedaje_habitacion_invitados)
    {
        //
    }
}
