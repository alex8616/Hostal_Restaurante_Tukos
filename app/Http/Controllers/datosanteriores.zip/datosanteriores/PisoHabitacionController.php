<?php

namespace App\Http\Controllers;

use App\Models\PisoHabitacion;
use Illuminate\Http\Request;

class PisoHabitacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PisoHabitacion  $pisoHabitacion
     * @return \Illuminate\Http\Response
     */
    public function show(PisoHabitacion $pisoHabitacion)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\PisoHabitacion  $pisoHabitacion
     * @return \Illuminate\Http\Response
     */
    public function edit(PisoHabitacion $pisoHabitacion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\PisoHabitacion  $pisoHabitacion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PisoHabitacion $pisoHabitacion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PisoHabitacion  $pisoHabitacion
     * @return \Illuminate\Http\Response
     */
    public function destroy(PisoHabitacion $pisoHabitacion)
    {
        //
    }
}
