<?php

namespace App\Http\Controllers;

use App\Models\UpdateStock;
use Illuminate\Http\Request;

class UpdateStockController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\UpdateStock  $updateStock
     * @return \Illuminate\Http\Response
     */
    public function show(UpdateStock $updateStock)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\UpdateStock  $updateStock
     * @return \Illuminate\Http\Response
     */
    public function edit(UpdateStock $updateStock)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\UpdateStock  $updateStock
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UpdateStock $updateStock)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\UpdateStock  $updateStock
     * @return \Illuminate\Http\Response
     */
    public function destroy(UpdateStock $updateStock)
    {
        //
    }
}
