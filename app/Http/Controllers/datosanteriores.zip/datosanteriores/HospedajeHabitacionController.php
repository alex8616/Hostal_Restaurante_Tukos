<?php

namespace App\Http\Controllers;

use App\Models\HospedajeHabitacion;
use Illuminate\Http\Request;

class HospedajeHabitacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\HospedajeHabitacion  $hospedajeHabitacion
     * @return \Illuminate\Http\Response
     */
    public function show(HospedajeHabitacion $hospedajeHabitacion)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\HospedajeHabitacion  $hospedajeHabitacion
     * @return \Illuminate\Http\Response
     */
    public function edit(HospedajeHabitacion $hospedajeHabitacion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\HospedajeHabitacion  $hospedajeHabitacion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, HospedajeHabitacion $hospedajeHabitacion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\HospedajeHabitacion  $hospedajeHabitacion
     * @return \Illuminate\Http\Response
     */
    public function destroy(HospedajeHabitacion $hospedajeHabitacion)
    {
        //
    }
}
