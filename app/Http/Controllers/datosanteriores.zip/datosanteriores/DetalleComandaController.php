<?php

namespace App\Http\Controllers;

use App\Models\DetalleComanda;
use Illuminate\Http\Request;

class DetalleComandaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DetalleComanda  $detalleComanda
     * @return \Illuminate\Http\Response
     */
    public function show(DetalleComanda $detalleComanda)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DetalleComanda  $detalleComanda
     * @return \Illuminate\Http\Response
     */
    public function edit(DetalleComanda $detalleComanda)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DetalleComanda  $detalleComanda
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DetalleComanda $detalleComanda)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DetalleComanda  $detalleComanda
     * @return \Illuminate\Http\Response
     */
    public function destroy(DetalleComanda $detalleComanda)
    {
        //
    }
}
