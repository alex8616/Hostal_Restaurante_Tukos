<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Festivale extends Model
{
    use HasFactory;
    protected $fillable = ['nombre_festival',
                            'descripcion_festival',
                            'fecha_festival'];
    
    //Relacion de uno a muchos
    public function registrofestivales(){
        return $this->hasMany(RegistroFestivale::class);
    }
    
    //Relacion de uno a muchos
    public function reservafestivales(){
        return $this->hasMany(ReservaFestivale::class);
    }
}
