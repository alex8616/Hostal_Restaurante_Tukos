<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Combo extends Model
{
    use HasFactory;
    protected $fillable = ['estado',
                           'Nombre_combo',
                           'Detalle_combo',
                           'Precio_combo'];

    //Relacion de uno a muchos
    public function detallefestival(){
        return $this->hasMany(detallefestival::class);
    }                      
}
