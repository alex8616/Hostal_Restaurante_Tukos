<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\PlatoController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\CategoriaController;
use App\Http\Controllers\ComandaController;
use App\Http\Controllers\ComandaMesaController;
use App\Http\Livewire\ReportesController;
use App\Http\Livewire\ReporteFacturaController;
use App\Http\Controllers\ReportFacturaController;
use App\Http\Livewire\ReporteMesaController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ReportMesaController;
use App\Http\Controllers\TipoClienteController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\MesaController;
use App\Http\Controllers\AmbienteController;
use App\Http\Controllers\ReservaController;
use App\Http\Controllers\DetalleClientesController;
use App\Http\Controllers\EmpresaController;
use App\Http\Controllers\CajaController;
use App\Http\Controllers\InventarioController;
use App\Http\Livewire\Articulos;
use App\Models\Ambiente;
//hostal xdd
use App\Http\Controllers\CategoriaHabitacionController;
use App\Http\Controllers\ClienteHostalController;
use App\Http\Controllers\HabitacionController;
use App\Http\Controllers\PisoHabitacionController;
use App\Http\Controllers\ProductoHostalController;
use App\Http\Controllers\ReporteHostalController;
use App\Models\ClienteHostal;
use App\Http\Controllers\BackupController;
use App\Http\Controllers\ControlCamareriaController;
use App\Http\Controllers\LibroNovedadeController;
use App\Http\Controllers\ProblemaController;
use App\Http\Controllers\WhatsAppController;
use App\Http\Controllers\PersonaController;
use App\Models\ControlCamareria;

Route::get('/', function () {
    return view('auth.login');
});

Route::resource('users', UserController::class)->names('admin.users');
;
Route::resource('roles', RoleController::class)->names('admin.roles');
;

Route::get('/home', [HomeController::class, 'index']);
Route::get('/home-dashboard', [HomeController::class, 'index'])->middleware('auth')->name('home-dashboard');


Route::get('report/pdf/{user}/{type}/{f1}/{f2}', [ReportController::class, 'reportePDF'])->name('reporte.pdf');
Route::get('report/pdf/{user}/{type}', [ReportController::class, 'reportePDF'])->name('reporte.pdf');

Route::get('report/pdffactura/{user}/{type}/{estadofactura}/{f1}/{f2}', [ReportFacturaController::class, 'reporteEXCEL'])->name('reporte.excel');
Route::get('report/pdffactura/{user}/{estadofactura}/{type}', [ReportFacturaController::class, 'reporteEXCEL'])->name('reporte.excel');
Route::get('report/factura_pdf/{user}/{type}/{estadofactura}/{f1}/{f2}', [ReportFacturaController::class, 'reportePDF'])->name('reporte.pdf');
Route::get('report/factura_pdf/{user}/{estadofactura}/{type}', [ReportFacturaController::class, 'reportePDF'])->name('reporte.pdf');

Route::get('report/pdfmesa/{user}/{type}/{f1}/{f2}', [ReportMesaController::class, 'reportePDF'])->name('reporte.pdfmesa');
Route::get('report/pdfmesa/{user}/{type}', [ReportMesaController::class, 'reportePDF'])->name('reporte.pdfmesa');

Route::resource('menu', MenuController::class)->names('admin.menu')->middleware('auth');
Route::post('/menu/guardar',[MenuController::class,'guardar']);
Route::post('/menu/creater',[MenuController::class,'creater']);
Route::get('/menu/listar',[MenuController::class,'show']);
Route::get('menu/pdf/{menu}', [MenuController::class, 'pdf'])->name('admin.menu.pdf');
Route::post('menu.addplus', [MenuController::class, 'addplus'])->name('admin.menu.addplus');


Route::get('calendar', [EventController::class, 'index'])->name('calendar.index')->middleware('auth');;
Route::post('calendar/create-event', [EventController::class, 'create'])->name('calendar.create');
Route::patch('calendar/edit-event', [EventController::class, 'edit'])->name('calendar.edit');
Route::delete('calendar/remove-event', [EventController::class, 'destroy'])->name('calendar.destroy');


//Route::resource('evento', EventController::class)->names('admin.evento')->middleware('auth');
Route::resource('mesa', MesaController::class)->names('admin.mesa')->middleware('auth');
Route::resource('plato', PlatoController::class)->names('admin.plato')->middleware('auth');
Route::resource('cliente', ClienteController::class)->names('admin.cliente')->middleware('auth');
Route::resource('categoria', CategoriaController::class)->except('show')->names('admin.categoria');
Route::resource('comanda', ComandaController::class)->names('admin.comanda')->middleware('auth');
Route::resource('tipopensionado', DetalleClientesController::class)->names('admin.tipopensionado')->middleware('auth');
Route::resource('ambiente', AmbienteController::class)->names('admin.ambiente')->middleware('auth');
Route::get('ambiente/{ambiente}/reserva', [AmbienteController::class, 'reserva'])->name('admin.ambiente.reserva');
Route::post('ambiente.reservastore', [AmbienteController::class, 'reservastore'])->name('admin.ambiente.reservastore');
Route::put('updatereserva/{id}', [AmbienteController::class, 'updatereserva'])->name('updatereserva');
Route::delete('ambiente.destroyreserva/{reserva}', [AmbienteController::class, 'destroyreserva'])->name('ambiente.destroyreserva');

Route::resource('reserva', ReservaController::class)->names('admin.reserva')->middleware('auth');
Route::resource('empresa', EmpresaController::class)->names('admin.empresa')->middleware('auth');
Route::resource('caja', CajaController::class)->names('admin.caja')->middleware('auth');

Route::get('caja.codigo', [CajaController::class, 'codigo'])->name('admin.caja.codigo');
Route::get('caja.articulos', [CajaController::class, 'articulos'])->name('admin.caja.articulos');
Route::get('caja/{caja}/registrar', [CajaController::class, 'registrar'])->name('admin.caja.registrar');
Route::get('caja/{caja}/registrar_restaurante', [CajaController::class, 'registrar_restaurante'])->name('admin.caja.registrar_restaurante');
Route::get('caja/{caja}/registrar_tarjeta', [CajaController::class, 'registrar_tarjeta'])->name('admin.caja.registrar_tarjeta');
Route::get('caja/{caja}/registrar_deposito', [CajaController::class, 'registrar_deposito'])->name('admin.caja.registrar_deposito');
Route::get('caja/{caja}/reporte_mensual', [CajaController::class, 'reporte_mensual'])->name('admin.caja.reporte_mensual');
Route::get('caja/{caja}/reporte_mensual_unique', [CajaController::class, 'reporte_mensual_unique'])->name('admin.caja.reporte_mensual_unique');

Route::get('caja.reportesfull', [CajaController::class, 'reportesfull'])->name('admin.caja.reportesfull');
Route::get('caja.reportesfullexportar', [CajaController::class, 'reportesfullexportar'])->name('admin.caja.reportesfullexportar');
Route::get('caja.reportescajapersonalizado', [CajaController::class, 'reportescajapersonalizado'])->name('admin.caja.reportescajapersonalizado');

//Route::post('/register', 'AuthController@register')->name('register');    
//Route::get('detallecaja/data', [CajaController::class, 'data'])->name('detallecaja.data');
Route::get('detallecaja/data/{caja}', [CajaController::class, 'data'])->name('detallecaja.data');
Route::get('detallecaja/datarestaurante/{caja}', [CajaController::class, 'datarestaurante'])->name('detallecaja.datarestaurante');
Route::get('detallecaja/datatarjetas/{caja}', [CajaController::class, 'datatarjetas'])->name('detallecaja.datatarjetas');
Route::get('detallecaja/datadepositos/{caja}', [CajaController::class, 'datadepositos'])->name('detallecaja.datadepositos');
Route::get('detallecaja/edit/{id}', [CajaController::class, 'edit'])->name('detallecaja.edit');
Route::put('detallecaja/{id}', [CajaController::class, 'update'])->name('detallecaja.update');
Route::put('detallecajaRestaurante/{id}', [CajaController::class, 'updateRestaurante'])->name('detallecaja.updateRestaurante');
Route::put('detallecajaTarjetas/{id}', [CajaController::class, 'updateTarjetas'])->name('detallecaja.updateTarjetas');
Route::put('detallecajaDepositos/{id}', [CajaController::class, 'updateDepositos'])->name('detallecaja.updateDepositos');
Route::post('caja.storedetallecaja', [CajaController::class, 'storedetallecaja'])->name('admin.caja.storedetallecaja');
Route::post('caja.storedetallecajaRestaurante', [CajaController::class, 'storedetallecajaRestaurante'])->name('admin.caja.storedetallecajaRestaurante');
Route::post('caja.storedetallecajaTarjetas', [CajaController::class, 'storedetallecajaTarjetas'])->name('admin.caja.storedetallecajaTarjetas');
Route::post('caja.storedetallecajaDepositos', [CajaController::class, 'storedetallecajaDepositos'])->name('admin.caja.storedetallecajaDepositos');
Route::delete('caja.destroydetallecaja/{detallecaja}', [CajaController::class, 'destroydetallecaja'])->name('caja.destroydetallecaja');
Route::delete('caja.destroydetallecajaRestaurante/{detallecaja}', [CajaController::class, 'destroydetallecajaRestaurante'])->name('caja.destroydetallecajaRestaurante');
Route::delete('caja.destroydetallecajaTarjetas/{detallecaja}', [CajaController::class, 'destroydetallecajaTarjetas'])->name('caja.destroydetallecajaTarjetas');
Route::delete('caja.destroydetallecajaDepositos/{detallecaja}', [CajaController::class, 'destroydetallecajaDepositos'])->name('caja.destroydetallecajaDepositos');
Route::post('/actualizar_estado', [CajaController::class, 'actualizarEstado'])->name('detallecaja.actualizar_estado');
Route::post('/actualizarEstadoRestaurante', [CajaController::class, 'actualizarEstadoRestaurante'])->name('detallecaja.actualizarEstadoRestaurante');
Route::post('caja.storedetallecajacerrar', [CajaController::class, 'storedetallecajacerrar'])->name('admin.caja.storedetallecajacerrar');


Route::post('caja.storecodigo', [CajaController::class, 'storecodigo'])->name('admin.caja.storecodigo');
Route::delete('caja.destroycodigo/{codigoCaja}', [CajaController::class, 'destroycodigo'])->name('caja.destroycodigo');
Route::put('updatecodigo/{id}', [CajaController::class, 'updatecodigo'])->name('updatecodigo');
Route::post('caja.storearticulo', [CajaController::class, 'storearticulo'])->name('admin.caja.storearticulo');
Route::put('updatearticulo/{id}', [CajaController::class, 'updatearticulo'])->name('updatearticulo');
Route::delete('caja.destroyarticulo/{articuloCaja}', [CajaController::class, 'destroyarticulo'])->name('caja.destroyarticulo');
Route::get('caja.buscador', [CajaController::class, 'buscador'])->name('admin.caja.buscador');
Route::get('caja/{caja}/buscarhostal', [CajaController::class, 'buscarhostal'])->name('admin.caja.buscarhostal');
Route::get('caja/{caja}/buscartarjeta', [CajaController::class, 'buscartarjeta'])->name('admin.caja.buscartarjeta');
Route::get('caja/{caja}/buscardeposito', [CajaController::class, 'buscardeposito'])->name('admin.caja.buscardeposito');
Route::get('caja/{caja}/buscarrestaurante', [CajaController::class, 'buscarrestaurante'])->name('admin.caja.buscarrestaurante');
Route::get('caja/{caja}/Cajapdf', [CajaController::class, 'Cajapdf'])->name('admin.caja.Cajapdf');
Route::get('caja/{caja}/reporte_mes_especifico', [CajaController::class, 'reporte_mes_especifico'])->name('admin.caja.reporte_mes_especifico');
Route::delete('caja.destroycaja/{caja}', [CajaController::class, 'destroycaja'])->name('caja.destroycaja');
Route::get('caja/{caja}/Cajaexcel', [CajaController::class, 'Cajaexcel'])->name('admin.caja.Cajaexcel');
Route::put('updatedetallecaja/{id}', [CajaController::class, 'updatedetallecaja'])->name('updatedetallecaja');
Route::put('updatedolar/{id}', [CajaController::class, 'updatedolar'])->name('updatedolar');

Route::get('comanda/{factura}/excelfacturas', [ComandaController::class, 'excelfacturas'])->name('admin.comanda.excelfacturas');

Route::post('mesa.crear', [MesaController::class, 'crear'])->name('admin.mesa.crear');

/*
esto son para inventario cocina 
*/
Route::get('cambio_de_estado/articulos/{articulo}', [Articulos::class, 'cambio_de_estado'])->name('cambio.estado.articulo');
Route::get('mesa.register', [MesaController::class, 'register'])->name('admin.mesa.register');
Route::get('inventario_cocina.index', [InventarioController::class, 'index'])->name('admin.inventario_cocina.index');
Route::post('inventario_cocina.store', [InventarioController::class, 'store'])->name('admin.inventario_cocina.store');
Route::delete('inventario_cocina.destroyinventarioarticulo/{articulo}', [InventarioController::class, 'destroyinventarioarticulo'])->name('inventario_cocina.destroyinventarioarticulo');
Route::get('cambio_de_estado/inventario_cocina/{articulo}', [InventarioController::class, 'cambio_de_estado'])->name('cambio.estado.inventario_cocina');
Route::get('inventario_cocina.Articulosexcel', [InventarioController::class, 'Articulosexcel'])->name('inventario_cocina.Articulosexcel');
Route::get('inventario_cocina.Articulospdf', [InventarioController::class, 'Articulospdf'])->name('inventario_cocina.articuloxportPDF');
Route::get('inventario_cocina/data', [InventarioController::class, 'data'])->name('inventario_cocina.data');
Route::get('articulos/edit/{id}', [InventarioController::class, 'edit'])->name('articulos.edit');
Route::put('updateinventarioarticulo/{id}', [InventarioController::class, 'updateinventarioarticulo'])->name('updateinventarioarticulo');
Route::put('updateinventarioarticulototal/{id}', [InventarioController::class, 'updateinventarioarticulototal'])->name('updateinventarioarticulototal');
//Route::put('detallecajaDepositos/{id}', [CajaController::class, 'updateDepositos'])->name('detallecaja.updateDepositos');
/*
hasta aqui
*/
Route::get('comanda.createtukomana', [ComandaController::class, 'createtukomana'])->name('admin.comanda.createtukomana');
Route::get('comanda.createcafeteria', [ComandaController::class, 'createcafeteria'])->name('admin.comanda.createcafeteria');

Route::get('comanda.createpensionado', [ComandaController::class, 'createpensionado'])->name('admin.comanda.createpensionado');
Route::post('comanda.storepensionado', [ComandaController::class, 'storepensionado'])->name('admin.comanda.storepensionado');
Route::post('comanda.storetukomana', [ComandaController::class, 'storetukomana'])->name('admin.comanda.storetukomana');
Route::post('comanda.storecafeteria', [ComandaController::class, 'storecafeteria'])->name('admin.comanda.storecafeteria');

Route::resource('comandamesa', ComandaMesaController::class)->names('admin.comandamesa')->middleware('auth');

Route::get('cambio_de_estado/comandas/{comanda}', [ComandaController::class, 'cambio_de_estado'])->name('cambio.estado.comanda');
Route::get('cambio_estado_factura/comandas/{factura}', [ComandaController::class, 'cambio_estado_factura'])->name('cambio.estado.factura');


Route::get('comandamesa/pdf/{comandaMesa}', [ComandaMesaController::class, 'pdf'])->name('admin.comandamesa.pdf');
Route::get('comandamesa.ReporteMesasDiario', [ComandaMesaController::class, 'ReporteMesasDiario'])->name('admin.comandamesa.ReporteMesasDiario');
Route::get('comandamesa.ReporteMesasMes', [ComandaMesaController::class, 'ReporteMesasMes'])->name('admin.comandamesa.ReporteMesasMes');
Route::get('comanda.ReporteMesasRangeFecha', [ComandaMesaController::class, 'ReporteMesasRangeFecha'])->name('admin.comandamesa.ReporteMesasRangeFecha');


Route::get('comanda/pdf/{comanda}', [ComandaController::class, 'pdf'])->name('admin.comanda.pdf');
Route::get('comanda/factura/{factura}', [ComandaController::class, 'factura'])->name('admin.comanda.factura');
Route::get('comanda/ticketfactura/{factura}', [ComandaController::class, 'ticketfactura'])->name('admin.comanda.ticketfactura');
Route::get('comanda.facturas', [ComandaController::class, 'facturas'])->name('admin.comanda.facturas');
Route::get('comanda.reporteFull', [ComandaController::class, 'reporteFull'])->name('comanda.reporteFull');
Route::get('comanda.TukoRangeFecha', [ComandaController::class, 'TukoRangeFecha'])->name('admin.comanda.TukoRangeFecha');
Route::get('comanda.ReporteTukomanasPDF', [ComandaController::class, 'ReporteTukomanasPDF'])->name('comanda.ReporteTukomanasPDF');
Route::get('comanda.ReportePedidosMes', [ComandaController::class, 'ReportePedidosMes'])->name('admin.comanda.ReportePedidosMes');
Route::get('comanda.ReportePedidosDetalle', [ComandaController::class, 'ReportePedidosDetalle'])->name('admin.comanda.ReportePedidosDetalle');
Route::get('comanda.ReportePedidosDiario', [ComandaController::class, 'ReportePedidosDiario'])->name('admin.comanda.ReportePedidosDiario');
Route::get('comanda.ReportePedidosRangeFecha', [ComandaController::class, 'ReportePedidosRangeFecha'])->name('admin.comanda.ReportePedidosRangeFecha');
Route::get('comanda.ReporteTukomanasDiario', [ComandaController::class, 'ReporteTukomanasDiario'])->name('admin.comanda.ReporteTukomanasDiario');
Route::get('comanda.ReporteTukomanasMes', [ComandaController::class, 'ReporteTukomanasMes'])->name('admin.comanda.ReporteTukomanasMes');
Route::get('comanda.ReporteTukomanasRangeFecha', [ComandaController::class, 'ReporteTukomanasRangeFecha'])->name('admin.comanda.ReporteTukomanasRangeFecha');
Route::get('comanda.ReporteCafeteriaDiario', [ComandaController::class, 'ReporteCafeteriaDiario'])->name('admin.comanda.ReporteCafeteriaDiario');
Route::get('comanda.ReporteCafeteriaMes', [ComandaController::class, 'ReporteCafeteriaMes'])->name('admin.comanda.ReporteCafeteriaMes');
Route::get('comanda.ReporteCafeteriaRangeFecha', [ComandaController::class, 'ReporteCafeteriaRangeFecha'])->name('admin.comanda.ReporteCafeteriaRangeFecha');
Route::get('comanda.ReporteComidaRapidaDiario', [ComandaController::class, 'ReporteComidaRapidaDiario'])->name('admin.comanda.ReporteComidaRapidaDiario');
Route::get('comanda.ReporteComidaRapidaMes', [ComandaController::class, 'ReporteComidaRapidaMes'])->name('admin.comanda.ReporteComidaRapidaMes');
Route::get('comanda.ReporteComidaRapidaRangeFecha', [ComandaController::class, 'ReporteComidaRapidaRangeFecha'])->name('admin.comanda.ReporteComidaRapidaRangeFecha');

Route::get('reports.component', ReportesController::class)->middleware('auth')->name('reports.reportes');
Route::get('reports.reporteFactura', ReporteFacturaController::class)->middleware('auth')->name('reports.reportefacturas');
Route::get('reports.ComponetMesa', ReporteMesaController::class)->middleware('auth')->name('reports.reportemesa');

Route::get('plato.listar', [PlatoController::class, 'listar'])->name('admin.plato.listar');
Route::get('plato.cat/{categorias}', [PlatoController::class, 'cat'])->name('admin.plato.cat');

Route::get('cliente.listvip', [ClienteController::class, 'listvip'])->name('admin.cliente.listvip');
Route::get('cliente.listcumple', [ClienteController::class, 'listcumple'])->name('admin.cliente.listcumple');
Route::get('pensionado.listpensionados', [TipoClienteController::class, 'listpensionados'])->name('admin.pensionado.listpensionados');
Route::get('pensionado.createtipo', [TipoClienteController::class, 'createtipo'])->name('admin.pensionado.createtipo');


Route::get('comanda.listapedidos', [ComandaController::class, 'listapedidos'])->name('admin.comanda.listapedidos');


Route::get('notifications/get',[ClienteController::class, 'getNotificationsData'])->name('notifications.get');

Route::resource('pensionado', TipoClienteController::class)->names('admin.pensionado')->middleware('auth');
Route::get('cambio_de_estado/pensionado/{tipocliente}', [TipoClienteController::class, 'cambio_de_estado'])->name('cambio.estado.tipocliente');

Route::put('updatecategoria/{id}', [CategoriaController::class, 'updatecategoria'])->name('updatecategoria');
Route::put('updatemenu/{id}', [MenuController::class, 'updatemenu'])->name('updatemenu');
Route::get('comanda.listacomidarapida', [ComandaController::class, 'listacomidarapida'])->name('admin.comanda.listacomidarapida');


Route::get('markAsRead', function(){
    auth()->user()->unreadNotifications->markAsRead();
    return redirect()->back();
})->name('markAsRead');


Route::put('updatecliente/{id}', [ClienteController::class, 'updatecliente'])->name('updatecliente');
Route::put('selectfactura/{id}', [ComandaController::class, 'selectfactura'])->name('selectfactura');
Route::put('updateplato/{id}', [PlatoController::class, 'updateplato'])->name('updateplato');
Route::put('updatemesa/{id}', [MesaController::class, 'updatemesa'])->name('updatemesa');

Route::get('pruebauno',[ComandaController::class, 'dato']);

Route::controller(ComandaController::class)->group(function(){
    Route::get('autocomplete', 'autocomplete')->name('autocomplete');
    Route::get('autocompletecliente', 'autocompletecliente')->name('autocompletecliente');
    Route::get('autocompletepensionado', 'autocompletepensionado')->name('autocompletepensionado');
});

Route::controller(CajaController::class)->group(function(){
    Route::get('autocompletearticulo', 'autocompletearticulo')->name('autocompletearticulo');
    Route::get('autocompletecodigo', 'autocompletecodigo')->name('autocompletecodigo');
});

Route::controller(MenuController::class)->group(function(){
    Route::get('menuautocomplete', 'menuautocomplete')->name('menuautocomplete');
});

Route::get('comanda.rangehour', [ComandaController::class, 'rangehour'])->name('admin.comanda.rangehour');
Route::get('comanda.reportehoras', [ComandaController::class, 'reportehoras'])->name('admin.comanda.reportehoras');

Route::get('ambiente/pdf/{reserva}', [AmbienteController::class, 'pdf'])->name('admin.ambiente.pdf');
Route::get('ambiente/{ambiente}/CrearReserva', [AmbienteController::class, 'CrearReserva'])->name('admin.ambiente.CrearReserva');
Route::get('ambiente/{ambiente}/ExportPDF', [AmbienteController::class, 'ExportPDF'])->name('admin.ambiente.ExportPDF');
Route::get('ambiente/{ambiente}/rangefecha', [AmbienteController::class, 'rangefecha'])->name('admin.ambiente.rangefecha');
Route::get('ambiente.reportegeneral', [AmbienteController::class, 'reportegeneral'])->name('admin.ambiente.reportegeneral');
Route::get('ambiente.reportegeneralfecha', [AmbienteController::class, 'reportegeneralfecha'])->name('admin.ambiente.reportegeneralfecha');

///hostal desde aqui xddd
Route::resource('categoriahabitacion', CategoriaHabitacionController::class)->names('hostal.categoriahabitacion')->middleware('auth');
Route::resource('pisohabitacion', PisoHabitacionController::class)->names('hostal.pisohabitacion')->middleware('auth');
Route::resource('habitacion', HabitacionController::class)->names('hostal.habitacion')->middleware('auth');
Route::resource('producto', ProductoHostalController::class)->names('hostal.producto')->middleware('auth');
Route::post('habitacion.hospedajestore', [HabitacionController::class, 'hospedajestore'])->name('hostal.habitacion.hospedajestore');
Route::get('habitacion/{habitacion}/CrearHospedaje', [HabitacionController::class, 'CrearHospedaje'])->name('hostal.habitacion.CrearHospedaje');
Route::controller(HabitacionController::class)->group(function(){
    Route::get('autocompletehostalcliente', 'autocompletehostalcliente')->name('autocompletehostalcliente');
    Route::get('autocompletehostalproducto', 'autocompletehostalproducto')->name('autocompletehostalproducto');
});
Route::get('habitacion/{habitacion}/DetalleHospedaje', [HabitacionController::class, 'DetalleHospedaje'])->name('hostal.habitacion.DetalleHospedaje');
Route::post('habitacion.ProductoStore', [HabitacionController::class, 'ProductoStore'])->name('hostal.habitacion.ProductoStore');
Route::post('habitacion.ServicioStore', [HabitacionController::class, 'ServicioStore'])->name('hostal.habitacion.ServicioStore');
Route::post('habitacion.ServicioDesayuno', [HabitacionController::class, 'ServicioDesayuno'])->name('hostal.habitacion.ServicioDesayuno');
Route::post('habitacion.ServicioLimpieza', [HabitacionController::class, 'ServicioLimpieza'])->name('hostal.habitacion.ServicioLimpieza');
Route::put('updatehabitacion/{id}', [HabitacionController::class, 'updatehabitacion'])->name('updatehabitacion');
Route::put('CambiarEstadoLimpieza/{id}', [HabitacionController::class, 'CambiarEstadoLimpieza'])->name('CambiarEstadoLimpieza');
Route::post('habitacion.reservastore', [HabitacionController::class, 'reservastore'])->name('hostal.habitacion.reservastore');
Route::get('habitacion/{habitacion}/CrearReserva', [HabitacionController::class, 'CrearReserva'])->name('hostal.habitacion.CrearReserva');
//Route::put('ConcluirReserva/{id}', [HabitacionController::class, 'ConcluirReserva'])->name('ConcluirReserva');
Route::get('habitacion/{habitacion}/DetalleReserva', [HabitacionController::class, 'DetalleReserva'])->name('hostal.habitacion.DetalleReserva');
Route::post('habitacion.ServicioDesayunoReserva', [HabitacionController::class, 'ServicioDesayunoReserva'])->name('hostal.habitacion.ServicioDesayunoReserva');
Route::get('habitacion.fullcalendar', [HabitacionController::class, 'fullcalendar'])->name('hostal.habitacion.fullcalendar');
Route::get('habitacion.ServiciosIncluidos', [HabitacionController::class, 'ServiciosIncluidos'])->name('hostal.habitacion.ServiciosIncluidos');
Route::post('habitacion.storeclienteinvitadoReserva', [HabitacionController::class, 'storeclienteinvitadoReserva'])->name('hostal.habitacion.storeclienteinvitadoReserva');
Route::post('habitacion.storeclienteinvitadoHospedaje', [HabitacionController::class, 'storeclienteinvitadoHospedaje'])->name('hostal.habitacion.storeclienteinvitadoHospedaje');


///
Route::get('habitacion/{reservahabitacion}/ConcluirReserva', [HabitacionController::class, 'ConcluirReserva'])->name('hostal.habitacion.ConcluirReserva');
Route::get('get_rooms_by_id', [HabitacionController::class, 'get_rooms_by_id'])->name('get_rooms_by_id');

Route::put('CancelarReserva/{reservahabitacion}', [HabitacionController::class, 'CancelarReserva'])->name('CancelarReserva');

Route::get('habitacion.ReservasLista', [HabitacionController::class, 'ReservasLista'])->name('hostal.habitacion.ReservasLista');
Route::get('habitacion/hospedajePDF/{hospedajehabitacion}', [HabitacionController::class, 'hospedajePDF'])->name('hostal.habitacion.hospedajePDF');
Route::get('habitacion/reservaPDF/{reservahabitacion}', [HabitacionController::class, 'reservaPDF'])->name('hostal.habitacion.reservaPDF');

Route::get('/api/reservations/check', [HabitacionController::class, 'checkAvailability']);

//ruta
//Route::post('/clientes/convertir-ubicacion', 'ClientController@convertirUbicacion');
Route::get('habitacion.pruebas', [HabitacionController::class, 'pruebas'])->name('hostal.habitacion.pruebas');
Route::post('habitacion.storepruebas', [HabitacionController::class, 'storepruebas'])->name('hostal.habitacion.storepruebas');
Route::post('habitacion.registrarcliente', [HabitacionController::class, 'registrarcliente'])->name('hostal.habitacion.registrarcliente');
//ruta

Route::get('habitacion.HospedajesLista', [HabitacionController::class, 'HospedajesLista'])->name('hostal.habitacion.HospedajesLista');        
Route::get('reportesHostal.index', [ReporteHostalController::class, 'index'])->name('hostal.reportesHostal.index');        
Route::get('habitacion.CamaraHotelera', [HabitacionController::class, 'CamaraHotelera'])->name('hostal.habitacion.CamaraHotelera');  
Route::get('habitacion.NovedadProblema', [HabitacionController::class, 'NovedadProblema'])->name('hostal.habitacion.NovedadProblema');  

Route::get('reportesHostal.ReporteRangeDate', [ReporteHostalController::class, 'ReporteRangeDate'])->name('hostal.reportesHostal.ReporteRangeDate');
Route::get('reportesHostal.ReporteMeses', [ReporteHostalController::class, 'ReporteMeses'])->name('hostal.reportesHostal.ReporteMeses');
Route::get('reportesHostal.ReporteSemanas', [ReporteHostalController::class, 'ReporteSemanas'])->name('hostal.reportesHostal.ReporteSemanas');
Route::get('/getDataByMonth/{month}', [ReporteHostalController::class, 'getDataByMonth']);
Route::get('/getDataByMonthRes/{month}', [ReporteHostalController::class, 'getDataByMonthRes']);

///rutas product
Route::get('/mathCaptchaImage', [ProductoHostalController::class, 'mathCaptchaImage'])->name('mathCaptchaImage');
Route::get('/getMathCaptchaImage', [ProductoHostalController::class, 'getMathCaptchaImage'])->name('getMathCaptchaImage');
Route::put('updatestock/{id}', [ProductoHostalController::class, 'updatestock'])->name('updatestock');
Route::post('/validateMathCaptcha', [ProductoHostalController::class, 'validateMathCaptcha'])->name('validateMathCaptcha');
Route::put('vender/{id}', [ProductoHostalController::class, 'vender'])->name('vender');
Route::get('productos.kardexpdf', [ProductoHostalController::class, 'kardexpdf'])->name('hostal.productos.kardexpdf');

//clientes
Route::get('ClienteHostal.index', [ClienteHostalController::class, 'index'])->name('hostal.ClienteHostal.index');        
Route::post('/store', [ClienteHostalController::class, 'store'])->name('store');
Route::get('ClienteHostal/InformacionCliente/{clienteHostal}', [ClienteHostalController::class, 'InformacionCliente'])->name('hostal.ClienteHostal.InformacionCliente');
Route::post('ClienteHostal.storelist', [ClienteHostalController::class, 'storelist'])->name('hostal.ClienteHostal.storelist');

Route::get('habitacion/{reservacion}/CambiarReserva', [HabitacionController::class, 'CambiarReserva'])->name('hostal.habitacion.CambiarReserva');
Route::get('habitacion/{hospedaje}/CambiarHospedaje', [HabitacionController::class, 'CambiarHospedaje'])->name('hostal.habitacion.CambiarHospedaje');
Route::get('habitacion/{reservacion}/CambiarReservaDatos', [HabitacionController::class, 'CambiarReservaDatos'])->name('hostal.habitacion.CambiarReservaDatos');


//validar documento
Route::get('validar-documento', [ClienteHostalController::class, 'validarDocumento']);

//backup date
Route::get('/backup', [BackupController::class, 'backup']);

//problemas
Route::get('problemas.listproblem', [ProblemaController::class, 'listproblem'])->name('hostal.problemas.listproblem');  

Route::post('problemas.store', [ProblemaController::class, 'store'])->name('hostal.problemas.store');
Route::put('/problemas/{id}', [ProblemaController::class, 'update'])->name('hostal.problemas.update');
Route::get('problemas/data', [ProblemaController::class, 'data'])->name('problemas.data');

//whatsap
Route::get('/send-whatsapp-message', [WhatsAppController::class, 'sendWhatsAppMessage']);

//backup planilla
Route::post('personal.store', [PersonaController::class, 'store'])->name('admin.personal.store');
Route::get('personal/edit/{id}', [PersonaController::class, 'edit'])->name('personal.edit');
Route::put('updatepersonal/{id}', [PersonaController::class, 'updatepersonal'])->name('updatepersonal');
Route::delete('/personal/{id}', [PersonaController::class, 'eliminar'])->name('eliminarpersonal');
Route::get('admin.personal.index', [PersonaController::class, 'index'])->name('admin.personal.index');
Route::get('personal/data', [PersonaController::class, 'data'])->name('personal.data');
Route::get('personal.AsistenciaHoja', [PersonaController::class, 'AsistenciaHoja'])->name('admin.personal.AsistenciaHoja');
//Route::get('comanda.ReportePedidosMes', [ComandaController::class, 'ReportePedidosMes'])->name('admin.comanda.ReportePedidosMes');

Route::post('novedades.StoreNovedadProblema', [LibroNovedadeController::class, 'StoreNovedadProblema'])->name('admin.novedades.StoreNovedadProblema');
Route::get('novedades.index', [LibroNovedadeController::class, 'index'])->name('admin.novedades.index');

Route::get('controlcamareria.index', [ControlCamareriaController::class, 'index'])->name('hostal.controlcamareria.index');        
Route::post('controlcamareria.storecontrol', [ControlCamareriaController::class, 'storecontrol'])->name('hostal.controlcamareria.storecontrol');
Route::post('controlcamareria.reporte', [ControlCamareriaController::class, 'reporte'])->name('hostal.controlcamareria.reporte');
